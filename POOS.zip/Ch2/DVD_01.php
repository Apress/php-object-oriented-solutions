<?php

require_once 'Product_03.php';

class Ch2_DVD extends Ch2_Product
{
	//class definition goes here
}
