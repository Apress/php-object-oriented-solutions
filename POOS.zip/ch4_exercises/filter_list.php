<pre>
<?php
print_r(filter_list());
?>
</pre>