<?php
require '../Ch2/Product_01.php';

$product = new Ch2_Product();
$product->_type = 'DVD';
?>