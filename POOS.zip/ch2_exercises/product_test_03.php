<?php
require '../Ch2/Product_02.php';

$product = new Ch2_Product();
echo $product->getProductType();
?>