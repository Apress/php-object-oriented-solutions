<?php
require '../Ch2/Book_06.php';

$book = new Ch2_Book('PHP Object-Oriented Solutions', 300);
echo $book;
?>