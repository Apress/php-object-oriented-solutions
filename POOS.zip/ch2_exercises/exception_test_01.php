<?php
require_once '../Ch2/Book_10.php';

$book = new Ch2_Book('PHP Object-Oriented Solutions', 'Wednesday');
echo $book;
?>