<?php
require '../Ch2/Product_01.php';

$product = new Ch2_Product();
echo $product->_type;
?>