<pre>
<?php
Reflection::export(new ReflectionClass('DateTimeZone'));
?>
</pre>