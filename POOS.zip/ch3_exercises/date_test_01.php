<?php
$date = new DateTime();
echo $date->format('l, F jS, Y');
?>