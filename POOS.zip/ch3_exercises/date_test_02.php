<?php
$date = new DateTime('next Thursday');
echo $date->format('l, F jS, Y');
?>