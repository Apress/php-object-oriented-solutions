<pre>
<?php
print_r(DateTimeZone::listAbbreviations());
?>
</pre>