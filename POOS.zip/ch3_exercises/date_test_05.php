<pre>
<?php
print_r(DateTimeZone::listIdentifiers());
?>
</pre>