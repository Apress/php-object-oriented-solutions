<pre>
<?php
Reflection::export(new ReflectionClass('DateTime'));
?>
</pre>