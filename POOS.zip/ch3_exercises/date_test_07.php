<pre>
<?php
$eastTZ = new DateTimeZone('America/New_York');
print_r($eastTZ->getTransitions());
?>
</pre>