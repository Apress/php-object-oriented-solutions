<?php
$xml = simplexml_load_file('inventory.xml');
echo '<pre>';
print_r($xml);
echo '</pre>';
?>
