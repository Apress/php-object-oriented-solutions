﻿Files for "PHP Object-Oriented Solutions" by David Powers
friends of ED (ISBN: 978-1-4302-1011-5)
##########################################################

Instructions for using these files are on page xix of the book. Please
read them!

The Pos folder is deliberately empty. It's for you to build the classes
yourself. If you're feeling particularly lazy, delete the Pos folder and
rename the finished_classes folder Pos.

Documentation for all classes can be viewed by launching class_docs/index.html
in a browser.

****************************************************
Why do the class files say "Copyright David Powers"?
****************************************************

I wrote the classes, so the copyright belongs to me. YOU ARE FREE TO USE
THE CLASSES IN YOUR OWN PROJECTS FOR COMMERCIAL OR PERSONAL USE WITHOUT
THE NEED TO PAY FEES OR ROYALTIES. What you cannot do is publish the
classes or sell them to anyone.

The classes have been thoroughly tested, but are supplied on an "as is"
basis. If you discover what you think is an error, please submit a report
to http://www.friendsofed.com/errataSubmission.html. I will also try to 
assist with problems related to the book in the friends of ED forum at
http://www.friendsofed.com/forums.

If you find the classes and/or book helpful, please spread the word by
telling your friends, and consider submitting a review to Amazon.com or 
other online bookstore. Also consider using the Amazon links on my
website (http://foundationphp.com/). Anything you buy after following one
of the links (it doesn't have to be that particular item) brings me a 
small commission. If I have helped you, it's an easy way to say thank you
without any extra cost to you.

David Powers
July 2008